import matplotlib.pyplot as plt

models = ["distilbert-base-uncased", "bert-base-uncased"]
dev_acc = [0.700, 0.6217125382262997]
test_acc = [0.694, 0.6370007007708479]

x = range(len(models))
width = 0.35

plt.figure(figsize=(8, 5))
plt.bar([i - width/2 for i in x], dev_acc, width=width, label="Dev Accuracy")
plt.bar([i + width/2 for i in x], test_acc, width=width, label="Test Accuracy")

plt.xticks(list(x), models, rotation=15)
plt.ylabel("Accuracy")
plt.title("Model Comparison on BoolQ")
plt.legend()
plt.tight_layout()
plt.savefig("model_comparison.png")
plt.show()
