import argparse
import os

from datasets import load_dataset
from openai import OpenAI


def build_context(dataset_split, start_index=8, num_examples=7):
    context_parts = [
        "Answer each BoolQ question with only True or False.",
        ""
    ]

    end_index = start_index + num_examples
    for question, answer, passage in zip(
        dataset_split[start_index:end_index]["question"],
        dataset_split[start_index:end_index]["answer"],
        dataset_split[start_index:end_index]["passage"],
    ):
        context_parts.append(f"Question: {question}?")
        context_parts.append(f"Passage: {passage}")
        context_parts.append(f"Answer: {str(answer)}")
        context_parts.append("")

    return "\n".join(context_parts)


def normalize_prediction(text):
    normalized = text.strip().lower()

    if normalized.startswith("true"):
        return "true"
    if normalized.startswith("false"):
        return "false"
    return normalized.split()[0] if normalized else ""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, default="gpt-3.5-turbo-instruct")
    parser.add_argument("--num_shots", type=int, default=7)
    parser.add_argument("--num_eval", type=int, default=30)
    args = parser.parse_args()

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY is not set. Please export it before running this script.")

    client = OpenAI(
        api_key=api_key,
        organization=os.getenv("OPENAI_ORGANIZATION"),
    )

    boolq = load_dataset("boolq")
    context = build_context(boolq["train"], start_index=8, num_examples=args.num_shots)

    correct_count = 0
    for idx, (question, answer, passage) in enumerate(
        zip(
            boolq["validation"][: args.num_eval]["question"],
            boolq["validation"][: args.num_eval]["answer"],
            boolq["validation"][: args.num_eval]["passage"],
        ),
        start=1,
    ):
        prompt = (
            f"{context}"
            f"Question: {question}?\n"
            f"Passage: {passage}\n"
            f"Answer:"
        )

        response = client.completions.create(
            model=args.model,
            prompt=prompt,
            temperature=0,
            max_tokens=5,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0,
        )

        raw_prediction = response.choices[0].text
        prediction = normalize_prediction(raw_prediction)
        gold = str(answer).lower()

        print(f"Example {idx}")
        print(f"Prediction: {prediction}")
        print(f"Gold: {gold}")
        print("-----------------------------")

        if prediction == gold:
            correct_count += 1

    accuracy = correct_count / args.num_eval
    print(f"accuracy = {accuracy}")


if __name__ == "__main__":
    main()
